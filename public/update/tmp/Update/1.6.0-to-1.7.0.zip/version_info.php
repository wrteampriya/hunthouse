<?php
return array('current_version' => '1.6.0','update_version' => '1.7.0');