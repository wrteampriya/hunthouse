<?php
return array('current_version' => '1.7.1','update_version' => '1.8.0');